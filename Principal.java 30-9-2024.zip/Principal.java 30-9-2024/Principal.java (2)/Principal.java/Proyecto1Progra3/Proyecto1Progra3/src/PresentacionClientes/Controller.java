package PresentacionClientes;
import PresentacionClientes.Model;
import PresentacionClientes.View;
import logic.Service;
import logic.Cliente;
import data.XmlPersister;
import data.Data;
import javax.swing.*;
import java.util.List;

public class Controller {
    private PresentacionClientes.Model model;
    private PresentacionClientes.View view;


    public void setModel(Model model) {
        this.model = model;
    }

    public void setView(View view) {
        this.view = view;
        this.view.setModel(model);
    }

    public void buscarCliente(Integer id, String nombre) {
        if (model == null) {
            throw new IllegalStateException("Modelo no inicializado.");
        }

        List<Cliente> resultados = model.buscarCliente(id, nombre);

        view.actualizarTabla(resultados);
    }



    public void guardarCliente(Integer id, String nombre, String numeroTelefono, String email, double porcentajeDescuento) {
        if (model == null) {
            throw new IllegalStateException("Modelo no inicializado.");
        }

        Cliente cliente = new Cliente(id,nombre, numeroTelefono, email, porcentajeDescuento);

        if (model.existeCliente(id)) {
            model.actualizarCliente(cliente);
        } else {
            model.agregarCliente(cliente);
        }


        guardarCambiosXML();
    }

    public void borrarCliente(Integer id) {
        if (model == null) {
            throw new IllegalStateException("Modelo no inicializado.");
        }

        model.eliminarCliente(id);


        guardarCambiosXML();
    }

    private void guardarCambiosXML() {
        try {

            Data data = XmlPersister.instanceClientes().load();
            List<Cliente> clientes = model.getList();
            data.getClientes().clear();
            data.getClientes().addAll(clientes);

            XmlPersister.instanceClientes().store(data);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al guardar los cambios en el archivo XML: " + e.getMessage());
        }
    }
}
