package Presentacion;
import logic.Producto;
import logic.Service;

import java.util.List;

public class Controller {
    public View view;
    public Model model;
    public Controller controller;

    public Controller(View view, Model model, Controller controller) {
        model.init(Service.instance3().search(new Producto()));
        this.view = view;
        this.model = model;
        this.controller = controller;
        view.setController(this);
        view.setModel(model);
        model.commit();
    }

    public void search(Producto filter) throws Exception {
        List<Producto> rows = Service.instance3().search(filter);
        this.model.setList(rows);
        if (rows.isEmpty()) {
            throw new Exception("NINGUN REGISTRO COINCIDE");
        } else {
            this.model.setList(rows);
            this.model.setCurrent(new Producto());
            this.model.commit();
        }
    }

    public void save(Producto producto) throws Exception {
        Service.instance3().addProducto(producto);
        this.model.setCurrent(new Producto());
        this.model.setList(Service.instance3().getProducto());
        this.model.commit();
    }

    public void delete(int row) throws Exception {
        Producto e = (Producto)this.model.getList().get(row);
        Service.instance().delete(e);
        this.model.commit();
        this.model.setCurrent(e);
        this.model.commit();
    }

    public void edit(int row) {
        Producto e = (Producto)this.model.getList().get(row);

        try {
            this.model.setCurrent(Service.instance().read(e));
            this.model.commit();
        } catch (Exception var4) {
        }

    }
}
