import Presentacion.Controller;
import Presentacion.Model;
import Presentacion.View;
import PresentacionEstadisticas.ModelEstadistica;
import data.XmlPersister;
import java.awt.BorderLayout;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import logic.Producto;

public class Principal {
    public static Controller facturarController;
    public static PresentacionClientes.Controller clientesController;
    public static PresentacionCajeros.Controller cajerosController;
    public static PresentacionProductos.Controller productosController;

    public Principal() {
    }

    public static void main(String[] args) throws Exception {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();

        // Se inicializan modelos y vistas
        Model facturaModel = new Model();

        // Debugging statement
        System.out.println("Loading products from XML...");

        List<Producto> productos = XmlPersister.instanceProductos().load().getProductos();

        // Debugging statements to check the product list
        if (productos == null) {
            System.out.println("Error: productos is null.");
        } else {
            System.out.println("Productos cargados: " + productos);
            if (productos.isEmpty()) {
                System.out.println("Error: La lista de productos está vacía.");
            } else {
                facturaModel.setList(productos);

                View facturarView = new View();
                facturarView.setModel(facturaModel);
                facturarView.setController(facturarController);

                PresentacionClientes.View clienteView = new PresentacionClientes.View();
                PresentacionClientes.Model clienteModel = new PresentacionClientes.Model();
                clientesController = new PresentacionClientes.Controller();
                clientesController.setModel(clienteModel);
                clientesController.setView(clienteView);
                clienteView.setModel(clienteModel);
                clienteView.setController(clientesController);

                PresentacionCajeros.View cajerosView = new PresentacionCajeros.View();
                PresentacionCajeros.Model cajerosModel = new PresentacionCajeros.Model();
                cajerosController = new PresentacionCajeros.Controller();
                cajerosController.setModel(cajerosModel);
                cajerosController.setView(cajerosView);
                cajerosView.setModel(cajerosModel);
                cajerosView.setController(cajerosController);

                PresentacionProductos.View productosView = new PresentacionProductos.View();
                PresentacionProductos.Model productosModel = new PresentacionProductos.Model();
                productosController = new PresentacionProductos.Controller();
                productosController.setModel(productosModel);
                productosController.setView(productosView);
                productosView.setModel(productosModel);
                productosView.setController(productosController);

                PresentacionEstadisticas.View estadisticasView = new PresentacionEstadisticas.View();
                ModelEstadistica estadisticasModel = new ModelEstadistica();
                //estadisticasController = new PresentacionEstadisticas.Controller();
                //estadisticasController.setModel(estadisticasModelModel);
                //estadisticasController.setView(estadisticasViewView);
                //estadisticasView.setModel(estadisticasModel);
                //estadisticasView.setController(estadisticasController);


                ImageIcon facturarIcon = new ImageIcon(Principal.class.getResource("carrito-de-compras.png"));
                ImageIcon clientesIcon = new ImageIcon(Principal.class.getResource("personas.png"));
                ImageIcon cajerosIcon = new ImageIcon(Principal.class.getResource("cajero.png"));
                ImageIcon productoIcon = new ImageIcon(Principal.class.getResource("producto.png"));
                ImageIcon estadisticasIcon = new ImageIcon(Principal.class.getResource("estadistica.png"));

                tabbedPane.addTab("Facturar ", facturarIcon, facturarView.getPanel());
                tabbedPane.addTab("Clientes ", clientesIcon, clienteView.getPanel());
                tabbedPane.addTab("Cajeros ", cajerosIcon, cajerosView.getPanel());
                tabbedPane.addTab("Productos", productoIcon, productosView.getPanel());
                tabbedPane.addTab("Estadisticas",estadisticasIcon,estadisticasView.getPanel());

                JPanel mainPanel = new JPanel(new BorderLayout());
                mainPanel.add(tabbedPane, BorderLayout.CENTER);

                window.getContentPane().add(mainPanel);
                window.setSize(800, 500);
                window.setResizable(true);
                window.setIconImage(new ImageIcon(Principal.class.getResource("calculadora.png")).getImage());
                window.setTitle("POS: Point Of Sale");
                window.setVisible(true);
            }
        }
    }
}
