package factura;

import logic.Producto;

public class ModelDetalleFactura {
    private Producto model;
    private int cantidad;
    private double precioUnitario;

    public ModelDetalleFactura(Producto model, int cantidad, double precioUnitario) {
        this.model = model;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public double getSubtotal() {
        return cantidad * precioUnitario;
    }

    public Producto getProducto() {
        return model;
    }
}