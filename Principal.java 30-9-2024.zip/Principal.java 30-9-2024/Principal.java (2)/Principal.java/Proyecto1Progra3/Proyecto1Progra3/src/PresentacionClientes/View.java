package PresentacionClientes;
import logic.Cliente;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javax.swing.table.TableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class View implements Observer {
    private JPanel panel1;
    private JTextField textFieldID;
    private JTextField textFieldNombre;
    private JTextField textFieldTelefono;
    private JTextField textFieldEmail;
    private JTextField textFieldDescuento;
    private JButton guardarButton;
    private JButton borrarButton;
    private JButton limpiarButton;
    private JTextField textFieldBusqueda;
    private JButton buscarButton;
    private JButton reporteButton;
    private JTable table1;
    private Controller controller;
    private Model model;

    public View() {
        initializeComponents();
        configureActionListeners();
    }

    private void initializeComponents() {
        if (textFieldID == null || textFieldNombre == null || textFieldTelefono == null ||
                textFieldEmail == null || textFieldDescuento == null || reporteButton == null) {
            throw new IllegalStateException("Componentes no se han inicializado");
        }
    }

    private void configureActionListeners() {
        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarCliente();
            }
        });

        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarCliente();
            }
        });

        borrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarCliente();
            }
        });

        limpiarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        reporteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table1.getSelectedRow();
                if (row >= 0 && model != null) {
                    Cliente cliente = model.getList().get(row);
                    mostrarClienteEnCampos(cliente);
                }
            }
        });
    }

    public JPanel getPanel() {
        return panel1;
    }

    public void setModel(PresentacionClientes.Model model) {
        this.model = model;
        model.addObserver((o, arg) -> actualizarTabla(model.getList()));
        if (model != null) {
            actualizarTabla(model.getList());
        }
    }
    public void setController(PresentacionClientes.Controller controller) {
        this.controller = controller;
    }

    public void guardarCliente() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error al guardar el cliente");
            return;
        }
        try {

            // Validación de que haya datos
            if(textFieldID.getText().isEmpty()&&textFieldNombre.getText().isEmpty()&&textFieldTelefono.getText().isEmpty()&&textFieldEmail.getText().isEmpty()&&textFieldDescuento.getText().isEmpty()){
                textFieldID.setBackground(Color.RED);
                textFieldNombre.setBackground(Color.RED);
                textFieldTelefono.setBackground(Color.RED);
                textFieldEmail.setBackground(Color.RED);
                textFieldDescuento.setBackground(Color.RED);

                JOptionPane.showMessageDialog(null, "Error: No es posible guardar el producto, faltan todos los datos");
            }

            String idText = textFieldID.getText().trim();
            Integer id = Integer.parseInt(idText);

            // Validación del nombre
            String nombre = textFieldNombre.getText().trim();
            if (nombre.isEmpty() || !nombre.matches("[a-zA-Z]+")) {
                textFieldNombre.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: El nombre debe contener solo letras");
                return;
            }

            // Validación del teléfono
            String telefono = textFieldTelefono.getText().trim();
            if (telefono.isEmpty() || !telefono.matches("\\d+")) {
                textFieldTelefono.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: El teléfono debe contener solo números");
                return;
            }

            // Validación del email
            String email = textFieldEmail.getText().trim();
            if (email.isEmpty() || !email.matches("^[\\w-\\.]+@[\\w-\\.]+\\.[a-zA-Z]{2,}$")) {
                textFieldEmail.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: El email no tiene un formato válido");
                return;
            }

            String descuentoText = textFieldDescuento.getText().trim();
            double descuento = Double.parseDouble(descuentoText);

            ponerFondoBlanco();
            controller.guardarCliente(id, nombre, telefono, email, descuento);
        }
        catch (NumberFormatException e) {
                // Captura y maneja errores de conversión de números (ID o descuento)
                JOptionPane.showMessageDialog(null, "Error: ID o descuento contienen datos no válidos. Tienen que ser números.");
                textFieldID.setBackground(Color.RED);
                textFieldDescuento.setBackground(Color.RED);
        }
    }


    public void borrarCliente() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error: no es posible borrar el cliente. Por favor ingrese valores válidos");
            return;
        }
        try {
            Integer id = Integer.parseInt(textFieldID.getText());
            ponerFondoBlanco();
            controller.borrarCliente(id);
        } catch (NumberFormatException e) {
                if(textFieldID.getText().isEmpty()){
                    textFieldID.setBackground(Color.RED);
                    JOptionPane.showMessageDialog(null,"No es posible borrar el cliente por que falta el ID");
                }
        }
    }

    public void buscarCliente() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error: no es posible buscar el cliente");
            return;
        }
        try {
            String searchText = textFieldBusqueda.getText().trim();
            Integer id = searchText.isEmpty() ? null : (searchText.matches("\\d+") ? Integer.parseInt(searchText) : null);
            String nombre = searchText.isEmpty() || id != null ? null : searchText;
            controller.buscarCliente(id, nombre);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor digite un nuevo numero de identificacion.");
        }
    }

    public void limpiarCampos() {
        textFieldID.setText("");
        textFieldNombre.setText("");
        textFieldTelefono.setText("");
        textFieldEmail.setText("");
        textFieldDescuento.setText("");
        textFieldBusqueda.setText("");
        ponerFondoBlanco();
    }

    public void mostrarClienteEnCampos(Cliente cliente) {
        if (cliente != null) {
            textFieldID.setText(String.valueOf(cliente.getId()));
            textFieldNombre.setText(cliente.getNombre());
            textFieldTelefono.setText(cliente.getNumeroTelefono());
            textFieldEmail.setText(cliente.getEmail());
            textFieldDescuento.setText(String.valueOf(cliente.getPorcentajeDescuento()));
        }
    }

    public void actualizarTabla(List<Cliente> clientes) {
        String[] columnNames = {"ID", "Nombre", "Teléfono", "Email", "Descuento"};
        Object[][] data = new Object[clientes.size()][columnNames.length];

        for (int i = 0; i < clientes.size(); i++) {
            Cliente c = clientes.get(i);
            data[i][0] = c.getId();
            data[i][1] = c.getNombre();
            data[i][2] = c.getNumeroTelefono();
            data[i][3] = c.getEmail();
            data[i][4] = c.getPorcentajeDescuento();
        }

        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
        table1.setModel(tableModel);
        table1.setRowHeight(30);

        TableColumnModel columnModel = table1.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(1).setPreferredWidth(200);
        columnModel.getColumn(2).setPreferredWidth(150);
        columnModel.getColumn(3).setPreferredWidth(200);
        columnModel.getColumn(4).setPreferredWidth(100);
    }

    private void generarReporte() {
        TableModel model = table1.getModel();
        int rowCount = model.getRowCount();
        int columnCount = model.getColumnCount();
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("Reporte De Clientes.pdf"));
            document.open();

            document.add(new Paragraph("Reporte de Clientes    "));

            PdfPTable pdfTable = new PdfPTable(columnCount);
            for (int i = 0; i < columnCount; i++) {
                pdfTable.addCell(model.getColumnName(i));
            }

            for (int i = 0; i < rowCount; i++) {
                for (int j = 0; j < columnCount; j++) {
                    pdfTable.addCell(model.getValueAt(i, j).toString());
                }
            }

            document.add(pdfTable);
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(null, "No se puede generar el reporte: " + e.getMessage());
        } finally {
            document.close();
        }

        JOptionPane.showMessageDialog(null, "Reporte generado exitosamente.");
    }


    @Override
    public void update(Observable o, Object arg) {

    }
    public void ponerFondoBlanco(){
        textFieldID.setBackground(Color.WHITE);
        textFieldNombre.setBackground(Color.WHITE);
        textFieldTelefono.setBackground(Color.WHITE);
        textFieldEmail.setBackground(Color.WHITE);
        textFieldDescuento.setBackground(Color.WHITE);
    }
}
//
/////////////////////////////////

