package PresentacionCajeros;
import logic.Cajero;
import java.util.List;
import java.util.Observable;
import javax.swing.table.TableModel;
import java.util.ArrayList;
import data.XmlPersister;
import data.Data;

public class Model extends Observable {
    private List<Cajero> list;
    private Cajero current;
    private TableModel table;

    public Model() {
        list = new ArrayList<>();
        cargarCajeroDesdeXML();
    }

    public void setList(List<Cajero> list) {
        this.list = list;
        setChanged();
        notifyObservers();
    }

    public void setCurrent(Cajero current) {
        this.current = current;
        setChanged();
        notifyObservers();
    }

    public void setTable(TableModel table) {
        this.table = table;
        setChanged();
        notifyObservers();
    }

    public List<Cajero> getList() {
        return list;
    }

    public List<Cajero> buscarCajero(Integer id, String nombre) {
        List<Cajero> resultado = new ArrayList<>();
        for (Cajero p : list) {
            boolean coincide = true;
            if (id != null && !p.getId().equals(id)) {
                coincide = false;
            }
            if (nombre != null && !p.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                coincide = false;
            }
            if (coincide) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    public boolean existeCajero(Integer id) {
        return list.stream().anyMatch(p -> p.getId().equals(id));
    }

    public void agregarCajero(Cajero cajero) {
        list.add(cajero);
        setChanged();
        notifyObservers();
    }

    public void actualizarCajero(Cajero cajero) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(cajero.getId())) {
                list.set(i, cajero);
                setChanged();
                notifyObservers();
                return;
            }
        }
    }

    public void eliminarCajero(Integer id) {
        list.removeIf(p -> p.getId().equals(id));
        setChanged();
        notifyObservers();
    }

    private void cargarCajeroDesdeXML() {
        try {
            Data data = XmlPersister.instanceCajeros().load();
            setList(data.getCajeros());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
