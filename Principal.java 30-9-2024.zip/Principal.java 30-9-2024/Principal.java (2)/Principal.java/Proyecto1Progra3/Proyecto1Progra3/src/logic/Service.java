package logic;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import data.Data;
import data.XmlPersister;

public class Service {

    ///////////////////// DECLARACIONES //////////////////////////
    private static Service clientesInstance;
    private static Service cajerosInstance;
    private static Service productosInstance;

    public static Service instance() {
        if (clientesInstance == null) clientesInstance = new Service();
        return clientesInstance;
    }

    public static Service instance2() {
        if (cajerosInstance == null) cajerosInstance = new Service();
        return cajerosInstance;
    }

    public static Service instance3() {
        if (productosInstance == null) productosInstance = new Service();
        return productosInstance;
    }

    private Data data;
    private Data data2;
    private Data data3;

    private Service() {
        try {
            data = XmlPersister.instanceClientes().load();
            data2 = XmlPersister.instanceCajeros().load();
            data3 = XmlPersister.instanceProductos().load();
            System.out.println("Productos cargados: " + data3.getProductos().size());
        } catch (Exception e) {
            data = new Data();
            data2 = new Data();
            data3 = new Data();
            System.out.println("Error al cargar datos. Se inicializa una lista vacía.");
        }
    }

    ////////////////////////////// XML /////////////////////////
    public void stop() {
        try {
            XmlPersister.instanceClientes().store(data);
            XmlPersister.instanceCajeros().store(data2);
            XmlPersister.instanceProductos().store(data3);
            System.out.println("Datos guardados correctamente.");
        } catch (Exception e) {
            System.out.println("Error al guardar los datos: " + e);
        }
    }

    ///////////////////// MANEJO DE PRODUCTOS ///////////////
    public void addProducto(Producto producto) throws Exception {
        Producto existingProducto = data3.getProductos().stream()
                .filter(i -> i.getCodigo().equals(producto.getCodigo()))
                .findFirst()
                .orElse(null);

        if (existingProducto != null) {
            existingProducto.setDescripcion(producto.getDescripcion());
            existingProducto.setCodigo(producto.getCodigo());
        } else {
            data3.getProductos().add(producto);
        }

        // Guarda los productos después de la modificación
        stop();
    }

    public Producto read(Producto e) throws Exception {
        Producto result = data3.getProductos().stream()
                .filter(i -> i.getCodigo().equals(e.getCodigo()))
                .findFirst()
                .orElse(null);
        if (result != null) return result;
        else throw new Exception("Producto no existe");
    }

    public void update(Producto e) throws Exception {
        Producto result = this.read(e);
        if (result != null) {
            data3.getProductos().remove(result);
            data3.getProductos().add(e);
        } else {
            throw new Exception("Producto no existe");
        }

        // Guarda los productos después de la actualización
        stop();
    }

    public Producto delete(Producto producto) throws Exception {
        if (data3.getProductos().contains(producto)) {
            data3.getProductos().remove(producto);
        } else {
            throw new Exception("El producto no existe en la lista.");
        }

        // Guarda los productos después de la eliminación
        stop();
        return producto;
    }

    public List<Producto> search(Producto e) {
        return data3.getProductos().stream()
                .filter(i -> i.getCodigo().equals(e.getCodigo()))
                .sorted(Comparator.comparing(Producto::getCodigo))
                .collect(Collectors.toList());
    }

    ///////////////////// MANEJO DE CLIENTES ///////////////
    public void addCliente(Cliente cliente) throws Exception {
        Cliente existingCliente = data.getClientes().stream()
                .filter(i -> i.getId().equals(cliente.getId()))
                .findFirst()
                .orElse(null);

        if (existingCliente != null) {
            existingCliente.setNombre(cliente.getNombre());
            existingCliente.setNumeroTelefono(cliente.getNumeroTelefono());
            existingCliente.setEmail(cliente.getEmail());
            existingCliente.setPorcentajeDescuento(cliente.getPorcentajeDescuento());
        } else {
            data.getClientes().add(cliente);
        }

        // Guarda los clientes después de la modificación
        stop();
    }

    public Cliente readCliente(Cliente cliente) throws Exception {
        Cliente result = data.getClientes().stream()
                .filter(i -> i.getId().equals(cliente.getId()))
                .findFirst()
                .orElse(null);
        if (result != null) return result;
        else throw new Exception("Cliente no existe");
    }

    public void updateCliente(Cliente cliente) throws Exception {
        Cliente result = this.readCliente(cliente);
        if (result != null) {
            data.getClientes().remove(result);
            data.getClientes().add(cliente);
        } else {
            throw new Exception("Cliente no existe");
        }

        // Guarda los clientes después de la actualización
        stop();
    }

    public Cliente deleteCliente(Cliente cliente) throws Exception {
        if (data.getClientes().contains(cliente)) {
            data.getClientes().remove(cliente);
        } else {
            throw new Exception("Cliente no existe en la lista.");
        }

        // Guarda los clientes después de la eliminación
        stop();
        return cliente;
    }

    public List<Cliente> searchCliente(Cliente cliente) {
        return data.getClientes().stream()
                .filter(i -> i.getId().equals(cliente.getId()))
                .sorted(Comparator.comparing(Cliente::getId))
                .collect(Collectors.toList());
    }

    ///////////////////// MANEJO DE CAJEROS ///////////////
    public void addCajero(Cajero cajero) throws Exception {
        Cajero existingCajero = data2.getCajeros().stream()
                .filter(i -> i.getId().equals(cajero.getId()))
                .findFirst()
                .orElse(null);

        if (existingCajero != null) {
            existingCajero.setNombre(cajero.getNombre());
        } else {
            data2.getCajeros().add(cajero);
        }

        // Guarda los cajeros después de la modificación
        stop();
    }

    public Cajero readCajero(Cajero cajero) throws Exception {
        Cajero result = data2.getCajeros().stream()
                .filter(i -> i.getId().equals(cajero.getId()))
                .findFirst()
                .orElse(null);
        if (result != null) return result;
        else throw new Exception("Cajero no existe");
    }

    public void updateCajero(Cajero cajero) throws Exception {
        Cajero result = this.readCajero(cajero);
        if (result != null) {
            data2.getCajeros().remove(result);
            data2.getCajeros().add(cajero);
        } else {
            throw new Exception("Cajero no existe");
        }

        // Guarda los cajeros después de la actualización
        stop();
    }

    public Cajero deleteCajero(Cajero cajero) throws Exception {
        if (data2.getCajeros().contains(cajero)) {
            data2.getCajeros().remove(cajero);
        } else {
            throw new Exception("Cajero no existe en la lista.");
        }

        // Guarda los cajeros después de la eliminación
        stop();
        return cajero;
    }

    public List<Cajero> searchCajero(Cajero cajero) {
        return data2.getCajeros().stream()
                .filter(i -> i.getId().equals(cajero.getId()))
                .sorted(Comparator.comparing(Cajero::getId))
                .collect(Collectors.toList());
    }

    ////////////////////////// GETTERS ////////////////////////////////////
    public List<Producto> getProducto() { return data3.getProductos(); }
    public List<Cliente> getCliente() { return data.getClientes(); }
    public List<Cajero> getCajero() { return data2.getCajeros(); }
}
