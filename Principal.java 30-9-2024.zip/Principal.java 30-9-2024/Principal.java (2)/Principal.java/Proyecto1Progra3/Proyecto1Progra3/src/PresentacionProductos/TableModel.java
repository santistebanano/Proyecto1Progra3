package PresentacionProductos;
import logic.Producto;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class TableModel extends AbstractTableModel {
    private final String[] columnNames = {"Código", "Descripción", "Unidad de Medida", "Precio Unitario", "Existencias", "Categoría"};
    private final List<Producto> productos;

    public TableModel(List<Producto> productos) {
        this.productos = productos;
    }

    @Override
    public int getRowCount() {
        return productos.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Producto producto = productos.get(rowIndex);
        switch (columnIndex) {
            case 0: return producto.getCodigo();
            case 1: return producto.getDescripcion();
            case 2: return producto.getUnidadMedida();
            case 3: return producto.getPrecioBaseUnitario();
            case 4: return producto.getExistencias();
            case 5: return producto.getCategoria();
            default: throw new IndexOutOfBoundsException("indice no valido");
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}
