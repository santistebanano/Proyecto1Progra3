package PresentacionProductos;

import logic.Producto;
import data.XmlPersister;
import data.Data;
import javax.swing.*;
import java.util.List;

public class Controller {
    private Model model;
    private View view;


    public void setModel(Model model) {
        this.model = model;
    }

    public void setView(View view) {
        this.view = view;
        this.view.setModel(model);
    }

    public void buscarProductos(Integer codigo) {
        if (model == null) {
            throw new IllegalStateException("Modelo no inicializado.");
        }

        List<Producto> resultados = model.buscarProductos(codigo);

        view.actualizarTabla(resultados);
    }



    public void guardarProducto(Integer codigo, String descripcion, String unidadMedida, double precio, int existencia, String categoria) {
        if (model == null) {
            throw new IllegalStateException("Modelo no inicializado.");
        }

        Producto producto = new Producto(codigo, descripcion, unidadMedida, precio, existencia, categoria);

        if (model.existeProducto(codigo)) {
            model.actualizarProducto(producto);
        } else {
            model.agregarProducto(producto);
        }


        guardarCambiosXML();
    }

    public void borrarProducto(Integer codigo) {
        if (model == null) {
            throw new IllegalStateException("Modelo no inicializado.");
        }

        model.eliminarProducto(codigo);


        guardarCambiosXML();
    }

    private void guardarCambiosXML() {
        try {

            Data data = XmlPersister.instanceProductos().load();
            List<Producto> productos = model.getList();
            data.getProductos().clear();
            data.getProductos().addAll(productos);

            XmlPersister.instanceProductos().store(data);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al guardar los cambios en el archivo XML: " + e.getMessage());
        }
    }
}
