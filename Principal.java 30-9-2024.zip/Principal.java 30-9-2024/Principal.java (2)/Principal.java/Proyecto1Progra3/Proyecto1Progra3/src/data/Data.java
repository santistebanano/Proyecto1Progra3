package data;
import logic.Cajero;
import logic.Cliente;
import jakarta.xml.bind.annotation.*;
import logic.Producto;

import java.util.ArrayList;
import java.util.List;
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Data {


    @XmlElementWrapper(name = "clientes")
    @XmlElement(name = "cliente")
    private List <Cliente> clientes;

    @XmlElementWrapper(name = "cajeros")
    @XmlElement(name = "cajero")
    private List <Cajero> cajeros;

    @XmlElementWrapper(name = "productos")
    @XmlElement(name = "producto")
    private List <Producto> productos;

    public Data(){
        clientes = new ArrayList<>();
        cajeros = new ArrayList<>();
        productos = new ArrayList<>();

    }
    public List <Cliente> getClientes() {
        return clientes;
    }
    public List<Cajero> getCajeros() {
        return cajeros;
    }
    public List <Producto> getProductos() {
        return productos;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    public void setCajeros(List<Cajero> cajeros) {
        this.cajeros = cajeros;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }
}

