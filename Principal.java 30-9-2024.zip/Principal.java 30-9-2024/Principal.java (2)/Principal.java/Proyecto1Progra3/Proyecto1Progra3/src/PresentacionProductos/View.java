package PresentacionProductos;
import logic.Producto;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javax.swing.table.TableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Arc2D;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class View {

    private JPanel panel1;
    private JTable table1;
    private JTextField codigoText;
    private JTextField descripcionText;
    private JTextField UnidadText;
    private JTextField precioUnitarioText;
    private JTextField existenciasText;
    private JTextField categoriaTextField;
    private JTextField textField4;
    private JButton guardarButton;
    private JButton borrarButton;
    private JButton limpiarButton;
    private JButton buscarButton;
    private JButton reporteButton;
    private PresentacionProductos.Model model;
    private PresentacionProductos.Controller controller;

    public View() {
        initializeComponents();
        configureActionListeners();

    }

    private void initializeComponents() {
        if (codigoText == null || descripcionText == null || precioUnitarioText == null ||
                existenciasText == null || categoriaTextField == null || textField4 == null || reporteButton == null) {
            throw new IllegalStateException("Botones no se han inicializado");
        }
    }

       private void configureActionListeners() {
        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarProducto();
            }
        });

        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarProducto();
            }
        });

        borrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarProducto();
            }
        });

        limpiarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        reporteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table1.getSelectedRow();
                if (row >= 0 && model != null) {
                    Producto producto = model.getList().get(row);
                    mostrarProductoEnCampos(producto);
                }
            }
        });
    }

    public JPanel getPanel() {
        return panel1;
    }

    public void setModel(PresentacionProductos.Model model) {
        this.model = model;
        model.addObserver((o, arg) -> actualizarTabla(model.getList()));
        if (model != null) {
            actualizarTabla(model.getList());
        }
    }

    public void setController(PresentacionProductos.Controller controller) {
        this.controller = controller;
    }

    public void guardarProducto() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error al guardar el producto");
            return;
        }
        try {

            if(codigoText.getText().isEmpty()&&descripcionText.getText().isEmpty()&&UnidadText.getText().isEmpty()&&precioUnitarioText.getText().isEmpty()&&existenciasText.getText().isEmpty()&&categoriaTextField.getText().isEmpty()) {
                codigoText.setBackground(Color.RED);
                descripcionText.setBackground(Color.RED);
                UnidadText.setBackground(Color.RED);
                precioUnitarioText.setBackground(Color.RED);
                existenciasText.setBackground(Color.RED);
                categoriaTextField.setBackground(Color.RED);
            }

            Integer codigo = Integer.parseInt(codigoText.getText());

            String descripcion = descripcionText.getText().trim();
            if (descripcion.isEmpty() || !descripcion.matches("[a-zA-Z]+")) {
                descripcionText.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: La descripcion debe contener solo letras");
                return;
            }

            String unidadMedida = UnidadText.getText().trim();
            if (unidadMedida.isEmpty() || !unidadMedida.matches("[a-zA-Z]+")) {
                UnidadText.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: La unidad de medida debe contener solo letras");
                return;
            }

            double precio = Double.parseDouble(precioUnitarioText.getText());

            int existencias = Integer.parseInt(existenciasText.getText());

            String categoria = categoriaTextField.getText().trim();
            if (categoria.isEmpty() || !unidadMedida.matches("[a-zA-Z]+")) {
                categoriaTextField.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: La categoria debe contener solo letras");
                return;
            }

            ponerFondoBlanco();
            controller.guardarProducto(codigo, descripcion, unidadMedida, precio, existencias, categoria);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error: codigo, el precio o las existencias contienen datos no válidos. Tienen que ser números.");
            codigoText.setBackground(Color.RED);
            precioUnitarioText.setBackground(Color.RED);
            existenciasText.setBackground(Color.RED);
        }
    }

    public void borrarProducto() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error: no es posible borrar producto. Por favor ingrese valores validos");
            return;
        }
        try {

            if(codigoText.getText().isEmpty()) {
                codigoText.setBackground(Color.RED);
            }

            Integer codigo = Integer.parseInt(codigoText.getText());
            controller.borrarProducto(codigo);
            ponerFondoBlanco();
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: No es posible borrar el producto, falta el codigo");
        }
    }

    public void buscarProducto() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error: no es posible buscar el producto");
            return;
        }
        try {
            String searchText = textField4.getText().trim();
            Integer codigo = searchText.isEmpty() ? null : (searchText.matches("\\d+") ? Integer.parseInt(searchText) : null);
            String descripcion = searchText.isEmpty() || codigo != null ? null : searchText;
            controller.buscarProductos(codigo);
            ponerFondoBlanco();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor digite datos numéricos válidos.");
        }
    }


    public void limpiarCampos() {
        codigoText.setText("");
        descripcionText.setText("");
        UnidadText.setText("");
        precioUnitarioText.setText("");
        existenciasText.setText("");
        categoriaTextField.setText("");
        textField4.setText("");
        ponerFondoBlanco();

    }

    public void mostrarProductoEnCampos(Producto producto) {
        if (producto != null) {
            codigoText.setText(String.valueOf(producto.getCodigo()));
            descripcionText.setText(producto.getDescripcion());
            UnidadText.setText(producto.getUnidadMedida());
            precioUnitarioText.setText(String.valueOf(producto.getPrecioBaseUnitario()));
            existenciasText.setText(String.valueOf(producto.getExistencias()));
            categoriaTextField.setText(producto.getCategoria());
        }
    }

    public void actualizarTabla(List<Producto> productos) {
        String[] columnNames = {"Código", "Descripción", "Categoría", "Existencias", "Precio Unitario"};
        Object[][] data = new Object[productos.size()][columnNames.length];

        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            data[i][0] = p.getCodigo();
            data[i][1] = p.getDescripcion();
            data[i][2] = p.getCategoria();
            data[i][3] = p.getExistencias();
            data[i][4] = p.getPrecioBaseUnitario();
        }

        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
        table1.setModel(tableModel);
        table1.setRowHeight(30);

        TableColumnModel columnModel = table1.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(1100);
        columnModel.getColumn(1).setPreferredWidth(1100);
        columnModel.getColumn(2).setPreferredWidth(1100);
        columnModel.getColumn(3).setPreferredWidth(1100);
        columnModel.getColumn(4).setPreferredWidth(1100);
    }


    private void generarReporte() {
        TableModel model = table1.getModel();
        int rowCount = model.getRowCount();
        int columnCount = model.getColumnCount();
        Document document = new Document();
        try {

            PdfWriter.getInstance(document, new FileOutputStream("ReporteDeProductos.pdf"));
            document.open();

            document.add(new Paragraph("Reporte de Productos"));

            PdfPTable pdfTable = new PdfPTable(columnCount);
            for (int i = 0; i < columnCount; i++) {
                pdfTable.addCell(model.getColumnName(i));
            }

            for (int i = 0; i < rowCount; i++) {
                for (int j = 0; j < columnCount; j++) {
                    pdfTable.addCell(model.getValueAt(i, j).toString());
                }
            }

            document.add(pdfTable);
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(null, "No se puede generar un reporte " + e.getMessage());
        } finally {
            document.close();
        }

        JOptionPane.showMessageDialog(null, "Reporte generado exitosamente.");
    }
    public void ponerFondoBlanco(){
        codigoText.setBackground(Color.WHITE);
        descripcionText.setBackground(Color.WHITE);
        UnidadText.setBackground(Color.WHITE);
        precioUnitarioText.setBackground(Color.WHITE);
        existenciasText.setBackground(Color.WHITE);
        categoriaTextField.setBackground(Color.WHITE);
    }
}