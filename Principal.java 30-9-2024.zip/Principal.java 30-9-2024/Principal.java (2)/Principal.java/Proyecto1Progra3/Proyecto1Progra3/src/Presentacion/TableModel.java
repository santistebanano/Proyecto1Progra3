package Presentacion;

import logic.Producto;
import logic.Cliente;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class TableModel extends AbstractTableModel implements javax.swing.table.TableModel {
    static List<Producto> rows;
    int[] cols;
    Cliente cliente;
    public static final int CODIGO = 0;
    public static final int DESCRIPCION = 1;
    public static final int CATEGORIA = 2;
    public static final int EXISTENCIAS = 3;
    public static final int PRECIOBASEUNITARIO = 4;
    public static final int DESCUENTO = 5;
    public static final int NETO = 6;
    public static final int IMPORTE = 7;
    String[] colNames = new String[8];

    public TableModel(int[] cols, List<Producto> rows, Cliente cliente) {
        if (cols != null && rows != null && cliente != null) {
            this.cols = cols;
            TableModel.rows = rows;
            this.cliente = cliente;
            this.initColNames();
        } else {
            throw new IllegalArgumentException("Los parámetros no pueden ser nulos");
        }
    }

    public int getColumnCount() {
        return this.cols == null ? 0 : this.cols.length;
    }

    public String getColumnName(int col) {
        return this.colNames[this.cols[col]];
    }

    public Class<?> getColumnClass(int col) {
        switch (this.cols[col]) {
            default:
                return super.getColumnClass(col);
        }
    }

    public int getRowCount() {
        return rows.size();
    }

    public Object getValueAt(int row, int col) {
        Producto producto = (Producto)rows.get(row);
        switch (this.cols[col]) {
            case 0:
                return producto.getCodigo();
            case 1:
                return producto.getDescripcion();
            case 2:
                return producto.getCategoria();
            case 3:
                return producto.getExistencias();
            case 4:
                return producto.getPrecioBaseUnitario();
            case 5:
                return this.cliente.getPorcentajeDescuento();
            case 6:
                double precioUnitario = producto.getPrecioBaseUnitario();
                double descuento = precioUnitario * this.cliente.getPorcentajeDescuento() / 100.0;
                return precioUnitario - descuento;
            case 7:
                double neto = (Double)this.getValueAt(row, 6);
                return neto * (double)producto.getExistencias();
            default:
                return "";
        }
    }

    public static Producto getRowAt(int row) {
        return (Producto)rows.get(row);
    }

    private void initColNames() {
        this.colNames[0] = "Codigo";
        this.colNames[1] = "Articulo";
        this.colNames[2] = "Categoria";
        this.colNames[3] = "Cantidad";
        this.colNames[4] = "Precio";
        this.colNames[5] = "Descuento";
        this.colNames[6] = "Neto";
        this.colNames[7] = "Importe";
    }
}