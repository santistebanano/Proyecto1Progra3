package PresentacionProductos;

import logic.Producto;
import javax.swing.table.TableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import data.XmlPersister;
import data.Data;

public class Model extends Observable {
    private List<Producto> list;
    private Producto current;
    private TableModel table;

    public Model() {
        list = new ArrayList<>();
        cargarProductosDesdeXML();
    }

    public void setList(List<Producto> list) {
        this.list = list;
        setChanged();
        notifyObservers();
    }

    public void setCurrent(Producto current) {
        this.current = current;
        setChanged();
        notifyObservers();
    }

    public void setTable(TableModel table) {
        this.table = table;
        setChanged();
        notifyObservers();
    }

    public List<Producto> getList() {
        return list;
    }


    public List<Producto> buscarProductos(Integer codigo) {
        List<Producto> resultado = new ArrayList<>();
        for (Producto p : list) {
            boolean coincide = true;
            if (codigo != null && !p.getCodigo().equals(codigo)) {
                coincide = false;
            }
            if (coincide) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    public boolean existeProducto(Integer codigo) {
        return list.stream().anyMatch(p -> p.getCodigo().equals(codigo));
    }

    public void agregarProducto(Producto producto) {
        list.add(producto);
        setChanged();
        notifyObservers();
    }

    public void actualizarProducto(Producto producto) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getCodigo().equals(producto.getCodigo())) {
                list.set(i, producto);
                setChanged();
                notifyObservers();
                return;
            }
        }
    }

    public void eliminarProducto(Integer codigo) {
        list.removeIf(p -> p.getCodigo().equals(codigo));
        setChanged();
        notifyObservers();
    }

    private void cargarProductosDesdeXML() {
        try {
            Data data = XmlPersister.instanceProductos().load();
            setList(data.getProductos());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
