package PresentacionEstadisticas;

import factura.Model;
import logic.Producto;

import javax.swing.table.TableModel;
import java.util.List;
import java.util.Observable;

public class ModelEstadistica extends Observable {
    private List<Producto> list;
    private Model current;
    private TableModel table;
}
