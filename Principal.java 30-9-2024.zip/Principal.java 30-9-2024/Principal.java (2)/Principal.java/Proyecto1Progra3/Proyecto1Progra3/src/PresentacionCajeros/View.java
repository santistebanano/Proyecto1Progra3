package PresentacionCajeros;
import logic.Cajero;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javax.swing.table.TableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class View {
    private JPanel panel1;
    private JTextField textFieldID;
    private JTextField textNombre;
    private JTextField textFieldBusqueda;
    private JTable table1;
    private JButton guardarButton;
    private JButton limpiarButton;
    private JButton borrarButton;
    private JButton buscarButton;
    private JButton reporteButton;
    private Controller controller;
    private Model model;

    public View() {
        initializeComponents();
        configureActionListeners();
    }

    private void initializeComponents() {
        if (textFieldID == null || textNombre == null || textFieldBusqueda == null || reporteButton == null) {
            throw new IllegalStateException("Componentes no se han inicializado");
        }
    }

    private void configureActionListeners() {
        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarCajero();
            }
        });

        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarCajero();
            }
        });

        borrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarCajero();
            }
        });

        limpiarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        reporteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });

        table1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table1.getSelectedRow();
                if (row >= 0 && model != null) {
                    Cajero cajero = model.getList().get(row);
                    mostrarCajeroEnCampos(cajero);
                }
            }
        });
    }

    public JPanel getPanel() {
        return panel1;
    }

    public void setModel(PresentacionCajeros.Model model) {
        this.model = model;
        model.addObserver((o, arg) -> actualizarTabla(model.getList()));
        if (model != null) {
            actualizarTabla(model.getList());
        }
    }
    public void setController(PresentacionCajeros.Controller controller) {
        this.controller = controller;
    }

    public void guardarCajero() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error al guardar el cajero");
            return;
        }
        try {
            // Validación del ID
            String idText = textFieldID.getText().trim();
            if (idText.isEmpty()) {
                textFieldID.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: El ID no puede estar vacío");
                return;
            }
            Integer id = Integer.parseInt(idText);

            String nombre = textNombre.getText();

            if (!nombre.matches("[a-zA-Z]+")||textNombre.getText().isEmpty()) {
                textNombre.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: El nombre debe contener letras");
                return;
            }
            ponerFondoBlanco();

            controller.guardarCajero(id, nombre);

        }catch (NumberFormatException e) {
            // Validación si el ID no es un número
                textFieldID.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: El ID debe contener letras");
        }
    }

    public void borrarCajero() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error: no es posible borrar cajero. Por favor intenta nuevamente");
            return;
        }
        try {
            // Validación del ID
            String idText = textFieldID.getText().trim();
            if (idText.isEmpty()) {
                textFieldID.setBackground(Color.RED);
                JOptionPane.showMessageDialog(null, "Error: El ID no puede estar vacío");
                return;
            }
            Integer id = Integer.parseInt(idText);
            ponerFondoBlanco();

            controller.borrarCajero(id);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"No es posible borrar el cajero por que falta el ID");
        }
    }

    public void buscarCajero() {
        if (controller == null) {
            JOptionPane.showMessageDialog(null, "Error: no es posible buscar cajero");
            return;
        }
        try {
            String searchText = textFieldBusqueda.getText().trim();
            Integer id = searchText.isEmpty() ? null : (searchText.matches("\\d+") ? Integer.parseInt(searchText) : null);
            String nombre = searchText.isEmpty() || id != null ? null : searchText;
            controller.buscarCajero(id, nombre);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor digite un nuevo numero de identificacion.");
        }
    }

    public void limpiarCampos() {
        textFieldID.setText("");
        textNombre.setText("");
        textFieldBusqueda.setText("");
        ponerFondoBlanco();

    }

    public void mostrarCajeroEnCampos(Cajero cajero) {
        if (cajero != null) {
            textFieldID.setText(String.valueOf(cajero.getId()));
            textNombre.setText(cajero.getNombre());
        }
    }

    public void actualizarTabla(List<Cajero> cajero) {
        String[] columnNames = {"ID", "Nombre"};
        Object[][] data = new Object[cajero.size()][columnNames.length];

        for (int i = 0; i < cajero.size(); i++) {
            Cajero c = cajero.get(i);
            data[i][0] = c.getId();
            data[i][1] = c.getNombre();
        }

        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
        table1.setModel(tableModel);
        table1.setRowHeight(30);

        TableColumnModel columnModel = table1.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(1).setPreferredWidth(200);
    }

    private void generarReporte() {
        TableModel model = table1.getModel();
        int rowCount = model.getRowCount();
        int columnCount = model.getColumnCount();
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("Reporte De Cajeros.pdf"));
            document.open();

            document.add(new Paragraph("Reporte de Cajeros    "));

            PdfPTable pdfTable = new PdfPTable(columnCount);
            for (int i = 0; i < columnCount; i++) {
                pdfTable.addCell(model.getColumnName(i));
            }

            for (int i = 0; i < rowCount; i++) {
                for (int j = 0; j < columnCount; j++) {
                    pdfTable.addCell(model.getValueAt(i, j).toString());
                }
            }

            document.add(pdfTable);
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(null, "No se puede generar el reporte: " + e.getMessage());
        } finally {
            document.close();
        }

        JOptionPane.showMessageDialog(null, "Reporte generado exitosamente.");
    }
    public void ponerFondoBlanco(){
        textFieldID.setBackground(Color.WHITE);
        textNombre.setBackground(Color.WHITE);
    }


}