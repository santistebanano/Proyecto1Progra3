package data;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import logic.Cajero;
import logic.Cliente;
import logic.Producto;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

public class XmlPersister {
    private String path;
    private static XmlPersister clientesInstance;
    private static XmlPersister cajerosInstance;
    private static XmlPersister productosInstance;

    public static XmlPersister instanceClientes() {
        if (clientesInstance == null) {
            clientesInstance = new XmlPersister("clientes.xml");
        }
        return clientesInstance;
    }

    public static XmlPersister instanceCajeros() {
        if (cajerosInstance == null) {
            cajerosInstance = new XmlPersister("cajeros.xml");
        }
        return cajerosInstance;
    }

    public static XmlPersister instanceProductos() {
        if (productosInstance == null) {
            productosInstance = new XmlPersister("productos.xml");
        }
        return productosInstance;
    }

    private XmlPersister(String p) {
        this.path = p;
    }

    public Data load() throws Exception {
        Data data = new Data();
        List<Producto> productos = loadFromFile("productos.xml");
        data.setProductos(productos);
        System.out.println("Productos cargados correctamente: " + productos.size());

        List<Cliente> clientes = loadFromFile("clientes.xml");
        data.setClientes(clientes);
        System.out.println("Clientes cargados correctamente: " + clientes.size());

        List<Cajero> cajeros = loadFromFile("cajeros.xml");
        data.setCajeros(cajeros);
        System.out.println("Cajeros cargados correctamente: " + cajeros.size());

        return data;
    }

    private <T> List<T> loadFromFile(String filePath) throws Exception {
        JAXBContext jaxbContext = JAXBContext.newInstance(Data.class);
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(filePath);

        if (is == null) {
            throw new FileNotFoundException("No se pudo encontrar el archivo: " + filePath);
        }

        try {
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            Data data = (Data) unmarshaller.unmarshal(is);
            if (data == null) {
                throw new Exception("Error al cargar datos del archivo: " + filePath);
            }

            return getListByFile(filePath, data);
        } finally {
            is.close();
        }
    }

    private <T> List<T> getListByFile(String filePath, Data data) {
        if (filePath.equals("productos.xml")) {
            return (List<T>) data.getProductos();
        } else if (filePath.equals("clientes.xml")) {
            return (List<T>) data.getClientes();
        } else {
            return (List<T>) data.getCajeros();
        }
    }

    public void store(Data data) throws Exception {

        String outputPath = "/Resources" + this.path;
        File file = new File(outputPath);
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }

        try (OutputStream os = new FileOutputStream(file)) {
            JAXBContext jaxbContext = JAXBContext.newInstance(Data.class);
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); // Formato de salida
            marshaller.marshal(data, os);
            System.out.println("Archivo guardado correctamente en: " + outputPath);
        }
    }
}
