package Presentacion;
import logic.Cliente;
import logic.Producto;

import javax.swing.table.TableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Observer;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.table.TableModel;
import logic.Cliente;
import logic.Producto;

public class Model extends Observable {
    List<Producto> list;
    List<Producto> productosFactura;
    private Cliente clienteActual;
    Producto current;
    int changedProps;
    private TableModel table;
    public static int NONE = 0;
    public static int LIST = 1;
    public static int CURRENT = 2;
    public static int TYPES = 4;

    public Model() {
        this.changedProps = NONE;
        this.list = new ArrayList();
        this.productosFactura = new ArrayList();
    }

    public Cliente getClienteActual() {
        return this.clienteActual;
    }

    public void setClienteActual(Cliente clienteActual) {
        if (clienteActual == null) {
            throw new IllegalArgumentException("El cliente no puede ser nulo");
        } else {
            this.clienteActual = clienteActual;
            this.changedProps += LIST;
            this.commit();
        }
    }

    public void setProducto(List<Producto> list) {
        this.list = list;
    }

    public void addObserver(Observer o) {
        super.addObserver(o);
    }

    public void commit() {
        this.setChanged();
        this.notifyObservers(this.changedProps);
        this.changedProps = NONE;
    }

    public void init(List<Producto> list) {
        this.setList(list);
        this.setCurrent(new Producto());
    }

    public List<Producto> getList() {
        return this.list;
    }

    public Producto getCurrent() {
        return this.current;
    }

    public TableModel getTable() {
        return this.table;
    }

    public void setList(List<Producto> list) {
        this.list = list;
        this.changedProps += LIST;
    }

    public void setCurrent(Producto current) {
        this.changedProps += CURRENT;
        this.current = current;
    }

    public void agregarProductoFactura(Producto producto) {
        if (producto != null) {
            this.productosFactura.add(producto);
            this.changedProps += TYPES;
            this.commit();
        }

    }

    public List<Producto> getProductosFactura() {
        return this.productosFactura;
    }

    public void actualizarProductoEnFactura(Producto producto) {
        for(int i = 0; i < this.productosFactura.size(); ++i) {
            if (((Producto)this.productosFactura.get(i)).getCodigo().equals(producto.getCodigo())) {
                Producto productoEnFactura = (Producto)this.productosFactura.get(i);
                int cantidadOriginal = productoEnFactura.getExistencias();
                int cantidadNueva = producto.getExistencias();
                productoEnFactura.setExistencias(cantidadNueva);
                this.productosFactura.set(i, productoEnFactura);
                this.setChanged();
                this.notifyObservers(LIST);
                break;
            }
        }

    }
}
