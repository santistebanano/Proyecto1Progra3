package PresentacionClientes;
import logic.Cliente;
import javax.swing.table.AbstractTableModel;
import java.io.Serializable;
import java.util.List;

public class TableModel extends AbstractTableModel {
    private final String[] columnNames = {"Id","Nombre", "Telefono", "Email", "Descuento"};
    private final List<Cliente> clientes;

    public TableModel(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    @Override
    public int getRowCount() {
        return clientes.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Cliente cliente = clientes.get(rowIndex);
        switch (columnIndex) {
            case 0: return cliente.getId();
            case 1: return cliente.getNombre();
            case 2: return cliente.getEmail();
            case 3: return cliente.getNumeroTelefono();
            case 4: return cliente.getPorcentajeDescuento();
            default: throw new IndexOutOfBoundsException("indice no valido");
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}
