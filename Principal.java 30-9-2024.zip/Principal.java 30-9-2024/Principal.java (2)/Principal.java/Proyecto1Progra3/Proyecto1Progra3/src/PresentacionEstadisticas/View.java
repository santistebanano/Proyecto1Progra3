
package PresentacionEstadisticas;

import javax.swing.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.*;

public class View {
    private JPanel panel1;
    private JSplitPane datosGrafico;
    private JPanel ladoIzquierdo;
    private JPanel ladoDerecho;
    private JLabel tituloDatos;
    private JPanel desdeHasta;
    private JLabel labelDesde;
    private JLabel labelHasta;
    private JComboBox<Integer> SeleccionaDesdeAnos;
    private JComboBox<String> SeleccionaDesdeMeses;
    private JComboBox<String> SeleccionaHastaMeses;
    private JComboBox<Integer> SeleccionaHastaAnos;
    private JComboBox<Integer> SeleccionaDesdeDias;
    private JComboBox<Integer> SeleccionaHastaDias;
    private JLabel labelCategorias;
    private JComboBox<String> boxCategorias;
    private JButton checkButton;
    private JButton refreshButton;
    private JTable tablaDatos;
    private JLabel infoFacturas;

    Integer[] anos = {2024, 2023, 2022, 2021, 2020};
    String[] meses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
    Integer[] dias = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};

    public View() {
        initializeComponents();
        opcionesSelecciona();
        generaGrafico();
    }

    private void initializeComponents() {
        panel1 = new JPanel(new BorderLayout());

        // Configurar JSplitPane
        datosGrafico = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        datosGrafico.setDividerLocation(350);
        datosGrafico.setResizeWeight(0.5);

        // Panel izquierdo (Datos)
        ladoIzquierdo = new JPanel();
        ladoIzquierdo.setLayout(new GridLayout(9,1,1,1));
        ladoIzquierdo.setBorder(BorderFactory.createTitledBorder("Datos"));

        labelDesde = new JLabel("Desde");
        labelHasta = new JLabel("Hasta");

        SeleccionaDesdeAnos = new JComboBox<>();
        SeleccionaDesdeMeses = new JComboBox<>();
        SeleccionaHastaAnos = new JComboBox<>();
        SeleccionaHastaMeses = new JComboBox<>();

        labelCategorias = new JLabel("Categorías");
        boxCategorias = new JComboBox<>();

        tablaDatos = new JTable();
        JScrollPane tablaScrollPane = new JScrollPane(tablaDatos);

        // Añadir componentes al panel izquierdo
        ladoIzquierdo.add(labelDesde);
        ladoIzquierdo.add(SeleccionaDesdeAnos);
        ladoIzquierdo.add(SeleccionaDesdeMeses);
        ladoIzquierdo.add(labelHasta);
        ladoIzquierdo.add(SeleccionaHastaAnos);
        ladoIzquierdo.add(SeleccionaHastaMeses);
        ladoIzquierdo.add(labelCategorias);
        ladoIzquierdo.add(boxCategorias);
        ladoIzquierdo.add(tablaScrollPane);

        // Panel derecho (Gráfico)
        ladoDerecho = new JPanel();
        ladoDerecho.setLayout(new BorderLayout());
        ladoDerecho.setBorder(BorderFactory.createTitledBorder("Gráfico"));

        // Añadir ambos lados al SplitPane
        datosGrafico.setLeftComponent(ladoIzquierdo);
        datosGrafico.setRightComponent(ladoDerecho);

        // Añadir SplitPane al panel principal
        panel1.add(datosGrafico, BorderLayout.CENTER);
    }

    public JPanel getPanel() {
        return panel1;
    }

    public void opcionesSelecciona() {
        for (Integer losAnos : anos) {
            SeleccionaDesdeAnos.addItem(losAnos);
            SeleccionaHastaAnos.addItem(losAnos);
        }
        for (String losMeses : meses) {
            SeleccionaDesdeMeses.addItem(losMeses);
            SeleccionaHastaMeses.addItem(losMeses);
        }
    }

    public void generaGrafico() {
        // Gráfico de ventas
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Añadir datos al gráfico
        dataset.addValue(5, "Ejemplo", "2024");

        // Crear el gráfico
        JFreeChart elGrafico = ChartFactory.createLineChart(
                "Ventas por mes",    // Título del gráfico
                "Mes",               // Etiqueta del eje X
                "Ventas",            // Etiqueta del eje Y
                dataset,             // Datos
                PlotOrientation.VERTICAL,
                true,                // Incluir leyenda
                true,                // Usar tooltips
                false                // Generar URLs
        );

        ChartPanel chartPanel = new ChartPanel(elGrafico);
        chartPanel.setPreferredSize(new Dimension(500, 370));
        ladoDerecho.add(chartPanel, BorderLayout.CENTER);
    }
}
