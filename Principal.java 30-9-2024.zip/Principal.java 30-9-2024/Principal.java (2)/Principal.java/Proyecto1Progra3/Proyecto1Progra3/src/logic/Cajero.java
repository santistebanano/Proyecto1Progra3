package logic;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class Cajero {
    private Integer id;
    @XmlElement
    private String nombre;
    public Cajero() {
        this.id = 0;
        this.nombre = "";
    }
    public Cajero(Integer id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "logic.Cajero{" +
                ", Identificacion =" + id +
                ", Nombre='" + nombre + '\'' +
                '}';
    }
}