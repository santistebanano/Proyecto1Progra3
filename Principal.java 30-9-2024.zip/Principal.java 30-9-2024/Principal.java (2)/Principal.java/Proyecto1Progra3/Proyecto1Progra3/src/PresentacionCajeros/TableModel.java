package PresentacionCajeros;

import logic.Cajero;
import javax.swing.table.AbstractTableModel;
import java.io.Serializable;
import java.util.List;

public class TableModel extends AbstractTableModel {
    private final String[] columnNames = {"Id","Nombre"};
    private final List<Cajero> cajeros;

    public TableModel(List<Cajero> cajeros) {
        this.cajeros = cajeros;
    }

    @Override
    public int getRowCount() {
        return cajeros.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Cajero cajero = cajeros.get(rowIndex);
        switch (columnIndex) {
            case 0: return cajero.getId();
            case 1: return cajero.getNombre();

            default: throw new IndexOutOfBoundsException("indice no valido");
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}
