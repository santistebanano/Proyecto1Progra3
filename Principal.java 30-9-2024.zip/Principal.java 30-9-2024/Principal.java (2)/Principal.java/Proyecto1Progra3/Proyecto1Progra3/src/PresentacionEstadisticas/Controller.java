package PresentacionEstadisticas;

public class Controller {
    private ModelEstadistica model;
    private PresentacionEstadisticas.View view;

    public void setModel(ModelEstadistica model) {
        this.model = model;
    }

    public void setView(PresentacionEstadisticas.View view) {
        this.view = view;
    }
}
