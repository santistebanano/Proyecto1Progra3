package Presentacion;
import java.awt.*;
import java.util.Iterator;
import java.util.List;
import java.util.Observer;
import data.Data;
import data.XmlPersister;
import logic.Cajero;
import logic.Cliente;
import logic.Producto;

import java.util.Observable;
import javax.swing.*;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.*;

public class View implements Observer {
        private JPanel panel2;
        private JTextField textField1;
        private JButton agregarButton;
        private JButton cobrarButton;
        private JComboBox<String> SeleccionarClientes;
        private JComboBox<String> seleccionarCajeros;
        private JButton buscarButton;
        private JButton cantidadButton;
        private JButton quitarButton;
        private JButton descuentoButton;
        private JButton cancelarButton;
        private JTable table1;
        private JLabel Totales;
        private List<Cliente> clientes;
        Model model;
        Controller controller;

    public View() {

        this.SeleccionarClientes.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombreClienteSeleccionado = (String)View.this.SeleccionarClientes.getSelectedItem();
                if (nombreClienteSeleccionado != null && View.this.model != null) {
                    Iterator var3 = View.this.clientes.iterator();

                    while(var3.hasNext()) {
                        Cliente cliente = (Cliente)var3.next();
                        if (cliente.getNombre().equals(nombreClienteSeleccionado)) {
                            View.this.model.setClienteActual(cliente);
                            break;
                        }
                    }
                }
            }
        });
        this.table1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = View.this.table1.getSelectedRow();
                if (View.this.controller != null) {
                    View.this.controller.edit(row);
                }

            }
        });
        this.cobrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                View.this.abrirDialogoPago();
            }
        });
        this.descuentoButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = View.this.table1.getSelectedRow();
                if (row >= 0) {
                    TableModel var10000 = (TableModel)View.this.table1.getModel();
                    Producto productoSeleccionado = TableModel.getRowAt(row);
                    View.this.abrirDialogoDescuento(productoSeleccionado.getDescripcion());
                } else {
                    JOptionPane.showMessageDialog((Component)null, "Seleccione un producto para aplicar descuento.");
                }
            }
        });
        this.agregarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String texto = textField1.getText().trim();
                if (!texto.isEmpty()) {
                    Producto producto = buscarProducto(texto, Integer.valueOf(texto));
                    if (producto != null) {
                        model.agregarProductoFactura(producto);
                        textField1.setText("");
                    } else {
                        JOptionPane.showMessageDialog(panel2, "Producto no encontrado.");
                    }
                }
            }
        });
    }

    public JPanel getPanel() {
        return this.panel2;
    }

        public void setController(Controller controller) {
        this.controller = controller;
    }

        public void setModel(Model model) {
        this.model = model;
        model.addObserver(this);
        if (this.clientes == null || this.clientes.isEmpty()) {
            this.cargarArchivosDesdeXML();
        }

    }
    private Producto buscarProducto(String descripcion, Integer codigo) {
        for (Producto producto : model.getList()) {
            if ((descripcion != null && producto.getDescripcion().equalsIgnoreCase(descripcion)) ||
                    (codigo != null && producto.getCodigo().equals(codigo)))  {
                return producto;
            }
        }
        return null;
    }
        public void cargarArchivosDesdeXML() {
        if (this.model == null) {
            throw new IllegalStateException("El modelo no puede ser nulo al cargar archivos.");
        } else {
            try {
                Data data = XmlPersister.instanceClientes().load();
                this.clientes = data.getClientes();
                if (this.clientes == null || this.clientes.isEmpty()) {
                    throw new IllegalArgumentException("La lista de clientes no puede ser nula o vacía.");
                }

                Iterator var2 = this.clientes.iterator();

                while(var2.hasNext()) {
                    Cliente cliente = (Cliente)var2.next();
                    this.SeleccionarClientes.addItem(cliente.getNombre());
                }

                this.SeleccionarClientes.setSelectedIndex(0);
                Cliente clientePredeterminado = (Cliente)this.clientes.get(0);
                this.model.setClienteActual(clientePredeterminado);
                Data data1 = XmlPersister.instanceCajeros().load();
                List<Cajero> cajeros = data1.getCajeros();
                Iterator var5 = cajeros.iterator();

                while(var5.hasNext()) {
                    Cajero cajero = (Cajero)var5.next();
                    this.seleccionarCajeros.addItem(cajero.getNombre());
                }
            } catch (Exception var10) {
                var10.printStackTrace();
                JOptionPane.showMessageDialog((Component)null, "Error cargando los datos desde XML");
            }
        }
    }

        public void abrirDialogoPago() {
        final JDialog dialogoPago = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this.panel2), "Método de Pago", true);
        dialogoPago.setSize(400, 400);
        dialogoPago.setLocationRelativeTo(this.panel2);
        JPanel panel = new JPanel(new BorderLayout());
        JPanel importePanel = new JPanel(new FlowLayout(2));
        importePanel.add(new JLabel("Importe Total a Pagar:"));
        JTextField importeField = new JTextField(10);
        importeField.setEditable(false);
        importePanel.add(importeField);
        panel.add(importePanel, "East");
        JPanel pagosPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        pagosPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Pagos Recibidos"));
        JPanel efectivoPanel = new JPanel();
        efectivoPanel.add(new JLabel("Efectivo:"));
        final JTextField efectivoField = new JTextField(10);
        efectivoPanel.add(efectivoField);
        pagosPanel.add(efectivoPanel);
        JPanel tarjetaPanel = new JPanel();
        tarjetaPanel.add(new JLabel("Tarjeta:"));
        final JTextField tarjetaField = new JTextField(10);
        tarjetaPanel.add(tarjetaField);
        pagosPanel.add(tarjetaPanel);
        JPanel chequePanel = new JPanel();
        chequePanel.add(new JLabel("Cheque:"));
        final JTextField chequeField = new JTextField(10);
        chequePanel.add(chequeField);
        pagosPanel.add(chequePanel);
        JPanel sinpePanel = new JPanel();
        sinpePanel.add(new JLabel("Sinpe:"));
        final JTextField sinpeField = new JTextField(10);
        sinpePanel.add(sinpeField);
        pagosPanel.add(sinpePanel);
        panel.add(pagosPanel, "Center");
        JPanel botonesPanel = new JPanel();
        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Cancelar");
        botonesPanel.add(okButton);
        botonesPanel.add(cancelButton);
        panel.add(botonesPanel, "South");
        dialogoPago.add(panel);
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String efectivo = efectivoField.getText();
                String tarjeta = tarjetaField.getText();
                String cheque = chequeField.getText();
                String sinpe = sinpeField.getText();
                dialogoPago.dispose();
            }
        });
        this.cantidadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                View.this.abrirDialogoCantidad();
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialogoPago.dispose();
            }
        });
        dialogoPago.setVisible(true);
    }

        private void abrirDialogoCantidad() {
        final JDialog dialogoCantidad = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this.panel2), "Ingrese Cantidad", true);
        dialogoCantidad.setSize(300, 150);
        dialogoCantidad.setLocationRelativeTo(this.panel2);
        JPanel panel = new JPanel(new BorderLayout());
        JPanel cantidadPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        cantidadPanel.add(new JLabel("Cantidad:"));
        final JTextField cantidadField = new JTextField(10);
        cantidadPanel.add(cantidadField);
        panel.add(cantidadPanel, "Center");
        JPanel botonesPanel = new JPanel();
        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Cancelar");
        botonesPanel.add(okButton);
        botonesPanel.add(cancelButton);
        panel.add(botonesPanel, "South");
        dialogoCantidad.add(panel);
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int cantidad = Integer.parseInt(cantidadField.getText().trim());
                    if (cantidad <= 0) {
                        JOptionPane.showMessageDialog(dialogoCantidad, "La cantidad debe ser un número positivo.");
                        return;
                    }

                    int row = View.this.table1.getSelectedRow();
                    if (row >= 0) {
                        TableModel var10000 = (TableModel)View.this.table1.getModel();
                        Producto productoSeleccionado = TableModel.getRowAt(row);
                        int existencias = productoSeleccionado.getExistencias();
                        if (cantidad > existencias) {
                            JOptionPane.showMessageDialog(dialogoCantidad, "La cantidad ingresada excede las existencias disponibles.");
                        } else {
                            productoSeleccionado.setExistencias(cantidad);
                            View.this.model.actualizarProductoEnFactura(productoSeleccionado);
                            dialogoCantidad.dispose();
                        }
                    } else {
                        JOptionPane.showMessageDialog(dialogoCantidad, "Seleccione un producto para ingresar la cantidad.");
                    }
                } catch (NumberFormatException var6) {
                    JOptionPane.showMessageDialog(dialogoCantidad, "Por favor, ingrese un valor numérico válido.");
                }

            }
        });
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialogoCantidad.dispose();
            }
        });
        dialogoCantidad.setVisible(true);
    }

        public void abrirDialogoFacturacion() {
        if (this.model == null) {
            JOptionPane.showMessageDialog((Component)null, "Modelo no inicializado.");
        } else {
            final JDialog dialogoFacturacion = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this.panel2), "Buscar Producto", true);
            dialogoFacturacion.setSize(600, 400);
            dialogoFacturacion.setLocationRelativeTo(this.panel2);
            JPanel panel = new JPanel(new BorderLayout());
            JPanel busquedaPanel = new JPanel(new GridLayout(1, 2));
            final JTextField busquedaField = new JTextField();
            busquedaPanel.add(new JLabel("Descripción:"));
            busquedaPanel.add(busquedaField);
            final JTable tablaProductos = new JTable();
            JScrollPane scrollPane = new JScrollPane(tablaProductos);
            panel.add(busquedaPanel, "North");
            panel.add(scrollPane, "Center");
            JPanel botonesPanel = new JPanel();
            JButton agregarButton = new JButton("Agregar");
            JButton cancelarButton = new JButton("Cancelar");
            botonesPanel.add(agregarButton);
            botonesPanel.add(cancelarButton);
            panel.add(botonesPanel, "South");
            dialogoFacturacion.add(panel);
            List<Producto> productos = this.model.getList();
            int[] cols = new int[]{0, 1, 2, 3, 4, 5, 6, 7};
            final TableModel tableModel = new TableModel(cols, productos, this.model.getClienteActual());
            tablaProductos.setModel(tableModel);
            tablaProductos.setRowHeight(30);
            TableColumnModel columnModel = tablaProductos.getColumnModel();
            columnModel.getColumn(1).setPreferredWidth(200);
            busquedaField.addKeyListener(new KeyAdapter() {
                public void keyReleased(KeyEvent e) {
                    String filtro = busquedaField.getText().toLowerCase();
                    TableRowSorter<TableModel> sorter = new TableRowSorter(tableModel);
                    tablaProductos.setRowSorter(sorter);
                    sorter.setRowFilter(RowFilter.regexFilter(filtro, new int[0]));
                }
            });

            this.buscarButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    View.this.abrirDialogoBusqueda();
                }
            });
            cancelarButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dialogoFacturacion.dispose();
                }
            });
            dialogoFacturacion.setVisible(true);
        }
    }

        private void abrirDialogoBusqueda() {
        final JDialog dialogoBusqueda = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this.panel2), "Buscar Producto", true);
        dialogoBusqueda.setSize(600, 400);
        dialogoBusqueda.setLocationRelativeTo(this.panel2);
        JPanel panel = new JPanel(new BorderLayout());
        JPanel busquedaPanel = new JPanel(new GridLayout(1, 2));
        final JTextField busquedaField = new JTextField();
        busquedaPanel.add(new JLabel("Descripción:"));
        busquedaPanel.add(busquedaField);
        final JTable tablaProductos = new JTable();
        JScrollPane scrollPane = new JScrollPane(tablaProductos);
        panel.add(busquedaPanel, "North");
        panel.add(scrollPane, "Center");
        JPanel botonesPanel = new JPanel();
        JButton agregarButton = new JButton("Agregar");
        JButton cancelarButton = new JButton("Cancelar");
        botonesPanel.add(agregarButton);
        botonesPanel.add(cancelarButton);
        panel.add(botonesPanel, "South");
        dialogoBusqueda.add(panel);
        List<Producto> productos = this.model.getList();
        int[] cols = new int[]{0, 1, 2, 3, 4, 5, 6, 7};
        TableModel tableModel = new TableModel(cols, productos, this.model.getClienteActual());
        tablaProductos.setModel(tableModel);
        tablaProductos.setRowHeight(30);
        TableColumnModel columnModel = tablaProductos.getColumnModel();
        columnModel.getColumn(1).setPreferredWidth(200);
        final TableRowSorter<TableModel> sorter = new TableRowSorter(tableModel);
        tablaProductos.setRowSorter(sorter);
        busquedaField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String filtro = busquedaField.getText().toLowerCase();
                sorter.setRowFilter(RowFilter.regexFilter(filtro, new int[0]));
            }
        });

        cancelarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialogoBusqueda.dispose();
            }
        });
        dialogoBusqueda.setVisible(true);
    }

        public void abrirDialogoDescuento(String nombreProducto) {
        final JDialog dialogoDescuento = new JDialog((JFrame)SwingUtilities.getWindowAncestor(this.panel2), "Descuento", true);
        dialogoDescuento.setSize(400, 400);
        dialogoDescuento.setLocationRelativeTo(this.panel2);
        JPanel panel = new JPanel(new BorderLayout());
        JPanel descuentoPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        descuentoPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), nombreProducto));
        descuentoPanel.add(new JLabel("Descuento (%):"));
        final JTextField descuentoField = new JTextField(10);
        descuentoPanel.add(descuentoField);
        panel.add(descuentoPanel, "Center");
        JPanel botonesPanel = new JPanel();
        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Cancelar");
        botonesPanel.add(okButton);
        botonesPanel.add(cancelButton);
        panel.add(botonesPanel, "South");
        dialogoDescuento.add(panel);
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String descuentoTexto = descuentoField.getText();

                try {
                    double descuento = Double.parseDouble(descuentoTexto);
                    dialogoDescuento.dispose();
                } catch (NumberFormatException var5) {
                    JOptionPane.showMessageDialog(dialogoDescuento, "Por favor ingresa un valor numérico válido.");
                }

            }
        });
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialogoDescuento.dispose();
            }
        });
        dialogoDescuento.setVisible(true);
    }

    public class VentanaPOS {

        public static void main(String[] args) {
            JFrame frame = new JFrame("POS: Point Of Sale");
            frame.setSize(800, 600);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            // Panel principal
            JPanel panelPrincipal = new JPanel();
            panelPrincipal.setLayout(new BorderLayout());
            frame.add(panelPrincipal, BorderLayout.CENTER);

            // Crear el panel para los totales
            JPanel panelTotales = new JPanel();
            panelTotales.setLayout(new GridLayout(1, 4)); // 1 fila, 4 columnas

            // Etiquetas de totales
            JLabel lblArticulos = new JLabel("Artículos: ");
            JLabel lblSubtotal = new JLabel("Subtotal: ");
            JLabel lblDescuentos = new JLabel("Descuentos: ");
            JLabel lblTotal = new JLabel("Total:");
            lblTotal.setForeground(Color.BLUE); // Poner el total en azul

            // Agregar los totales al panel
            panelTotales.add(lblArticulos);
            panelTotales.add(lblSubtotal);
            panelTotales.add(lblDescuentos);
            panelTotales.add(lblTotal);

            // Agregar el panel de totales a la parte inferior del frame
            frame.add(panelTotales, BorderLayout.SOUTH);

            // Mostrar la ventana
            frame.setVisible(true);
        }
    }


    public void update(Observable o, Object arg) {
        int changedProps = (Integer)arg;
        Cliente cliente;
        List productosFactura;
        int[] cols;
        TableModel tableModel;
        TableColumnModel columnModel;
        if ((changedProps & Model.LIST) == Model.LIST) {
            cliente = this.model.getClienteActual();
            productosFactura = this.model.getProductosFactura();
            cols = new int[]{0, 1, 2, 3, 4, 5, 6, 7};
            tableModel = new TableModel(cols, productosFactura, cliente);
            this.table1.setModel(tableModel);
            this.table1.setRowHeight(30);
            columnModel = this.table1.getColumnModel();
            columnModel.getColumn(2).setPreferredWidth(200);
        }

        if ((changedProps & Model.TYPES) == Model.TYPES) {
            cliente = this.model.getClienteActual();
            productosFactura = this.model.getProductosFactura();
            cols = new int[]{0, 1, 2, 3, 4, 5, 6, 7};
            tableModel = new TableModel(cols, productosFactura, cliente);
            this.table1.setModel(tableModel);
            this.table1.setRowHeight(30);
            columnModel = this.table1.getColumnModel();
            columnModel.getColumn(2).setPreferredWidth(200);
        }
      }
    }