package PresentacionEstadisticas;

public class TableModel {
}
