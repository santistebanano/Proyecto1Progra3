package PresentacionClientes;
import logic.Cliente;
import java.util.List;
import java.util.Observer;
import java.util.Observable;
import javax.swing.table.TableModel;
import java.util.ArrayList;
import data.XmlPersister;
import data.Data;

public class Model extends Observable {
    private List<Cliente> list;
    private Cliente current;
    private TableModel table;

    public Model() {
        list = new ArrayList<>();
        cargarClienteDesdeXML();
    }

    public void setList(List<Cliente> list) {
        this.list = list;
        setChanged();
        notifyObservers();
    }

    public void setCurrent(Cliente current) {
        this.current = current;
        setChanged();
        notifyObservers();
    }

    public void setTable(TableModel table) {
        this.table = table;
        setChanged();
        notifyObservers();
    }

    public List<Cliente> getList() {
        return list;
    }

    public List<Cliente> buscarCliente(Integer id, String nombre) {
        List<Cliente> resultado = new ArrayList<>();
        for (Cliente p : list) {
            boolean coincide = true;
            if (id != null && !p.getId().equals(id)) {
                coincide = false;
            }
            if (nombre != null && !p.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                coincide = false;
            }
            if (coincide) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    public boolean existeCliente(Integer id) {
        return list.stream().anyMatch(p -> p.getId().equals(id));
    }

    public void agregarCliente(Cliente cliente) {
        list.add(cliente);
        setChanged();
        notifyObservers();
    }

    public void actualizarCliente(Cliente cliente) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(cliente.getId())) {
                list.set(i, cliente);
                setChanged();
                notifyObservers();
                return;
            }
        }
    }

    public void eliminarCliente(Integer id) {
        list.removeIf(p -> p.getId().equals(id));
        setChanged();
        notifyObservers();
    }

    private void cargarClienteDesdeXML() {
        try {
            Data data = XmlPersister.instanceProductos().load();
            setList(data.getClientes());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

