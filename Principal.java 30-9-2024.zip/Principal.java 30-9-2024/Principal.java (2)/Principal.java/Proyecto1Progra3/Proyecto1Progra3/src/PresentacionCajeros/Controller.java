package PresentacionCajeros;

import logic.Cajero;
import data.XmlPersister;
import data.Data;
import javax.swing.*;
import java.util.List;

public class Controller {
    private PresentacionCajeros.Model model;
    private PresentacionCajeros.View view;


    public void setModel(Model model) {
        this.model=model;
    }

    public void setView(View view) {
        this.view = view;
        this.view.setModel(model);
    }

    public void buscarCajero(Integer id, String nombre) {
        if (model == null) {
            throw new IllegalStateException("No se encontro el cajero");
        }

        List<Cajero> resultados = model.buscarCajero(id, nombre);

        view.actualizarTabla(resultados);
    }



    public void guardarCajero(Integer id, String nombre) {
        if (model == null) {
            throw new IllegalStateException("Error al guardar Informacion.");
        }

        Cajero cajero = new Cajero(id,nombre);

        if (model.existeCajero(id)) {
            model.actualizarCajero(cajero);
        } else {
            model.agregarCajero(cajero);
        }


        guardarCambiosXML();
    }

    public void borrarCajero(Integer id) {
        if (model == null) {
            throw new IllegalStateException("No fue posible eliminar el cajero.");
        }

        model.eliminarCajero(id);


        guardarCambiosXML();
    }

    private void guardarCambiosXML() {
        try {

            Data data = XmlPersister.instanceCajeros().load();
            List<Cajero> cajeros = model.getList();
            data.getCajeros().clear();
            data.getCajeros().addAll(cajeros);

            XmlPersister.instanceCajeros().store(data);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al guardar los cambios en el archivo XML: " + e.getMessage());
        }
    }
}
